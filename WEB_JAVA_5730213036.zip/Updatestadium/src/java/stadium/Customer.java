package stadium;

public class Customer  implements java.io.Serializable {


     private Integer customerId;
     private String name;
     private String lastname;
     private String tel;
     private String email;
     private int identificationId;
     private String password;

    public Customer() {
    }

    public Customer(String name, String lastname, String tel, String email, int identificationId, String password) {
       this.name = name;
       this.lastname = lastname;
       this.tel = tel;
       this.email = email;
       this.identificationId = identificationId;
       this.password = password;
    }

    Customer(String customerId, String firstname, String lastname) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Customer(int customeridd, String firstname, String lastname) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Customer(int customeridd, String Name, String Lastname, String Tel, String Email, String Identification) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Customer(int customeridd, String Name, String Lastname, String Tel, String Email, String Identification, String Password) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Customer(int customeridd, String Name, String Lastname, String Tel, String Email, int IdentificationID, String Password) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Customer(String Name, String Lastname, String Tel, String Email, int IdentificationID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
   
    public Integer getCustomerId() {
        return this.customerId;
    }
    
    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }
    public String getName() {
        return this.name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    public String getLastname() {
        return this.lastname;
    }
    
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }
    public String getTel() {
        return this.tel;
    }
    
    public void setTel(String tel) {
        this.tel = tel;
    }
    public String getEmail() {
        return this.email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    public int getIdentificationId() {
        return this.identificationId;
    }
    
    public void setIdentificationId(int identificationId) {
        this.identificationId = identificationId;
    }
    public String getPassword() {
        return this.password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }




}


