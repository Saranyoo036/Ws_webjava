package stadium;

public class Reservation  implements java.io.Serializable {


     private Integer reservId;
     private int customerId;
     private int price;

    public Reservation() {
    }

    public Reservation(int customerId, int price) {
       this.customerId = customerId;
       this.price = price;
    }
   
    public Integer getReservId() {
        return this.reservId;
    }
    
    public void setReservId(Integer reservId) {
        this.reservId = reservId;
    }
    public int getCustomerId() {
        return this.customerId;
    }
    
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }
    public int getPrice() {
        return this.price;
    }
    
    public void setPrice(int price) {
        this.price = price;
    }




}


